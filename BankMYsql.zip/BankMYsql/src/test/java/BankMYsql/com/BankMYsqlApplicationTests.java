package BankMYsql.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankMYsqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
