package BankMYsql.com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankMYsqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankMYsqlApplication.class, args);
	}

}
